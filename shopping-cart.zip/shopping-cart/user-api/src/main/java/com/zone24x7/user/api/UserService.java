/*
 * Copyright (C) 2016-2017 Lightbend Inc. <https://www.lightbend.com>
 */
package com.zone24x7.user.api;

import static com.lightbend.lagom.javadsl.api.Service.named;

import akka.Done;
import akka.NotUsed;
import com.lightbend.lagom.javadsl.api.Descriptor;
import com.lightbend.lagom.javadsl.api.Service;
import com.lightbend.lagom.javadsl.api.ServiceCall;
import com.lightbend.lagom.javadsl.api.transport.Method;


public interface UserService extends Service {

  ServiceCall<NotUsed, User> getUser(String id);

  ServiceCall<User, Done> addUser();

  @Override
  default Descriptor descriptor() {
    // @formatter:off
    return named("user").withCalls(
        Service.restCall(Method.GET,"/api/user/:id",  this::getUser),
        Service.restCall(Method.POST,"/api/user",  this::addUser)
      ).withAutoAcl(true);
    // @formatter:on
  }
}
