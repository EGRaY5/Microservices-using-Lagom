package com.zone24x7.user.impl;

import com.zone24x7.user.api.User;

import java.util.HashMap;
import java.util.Map;

public class InMemoryUserRepository implements UserRepository {

    Map<String, User> userMap = new HashMap<>();

    public InMemoryUserRepository() {
        User nimal = new User();
        nimal.setId("001");
        nimal.setAge(12);
        nimal.setName("nimal");
        nimal.setAddress("nimal's address");

        User kamal = new User();
        kamal.setId("002");
        kamal.setAge(20);
        kamal.setName("kamal");
        kamal.setAddress("kamal's address");

        User saman = new User();
        saman.setId("003");
        saman.setAge(22);
        saman.setName("saman");
        saman.setAddress("saman's address");

        userMap.put("001",nimal);
        userMap.put("002",kamal);
        userMap.put("003",saman);

    }

    @Override
    public User getUser(String id) {
        return userMap.get(id);
    }

    @Override
    public void addUser(User user) {
        userMap.put(user.getId(),user);
    }

    @Override
    public void deleteUser(String id) {
        //todo implement this
    }
}
