package com.zone24x7.user.impl;

import com.google.inject.ImplementedBy;
import com.zone24x7.user.api.User;


@ImplementedBy(InMemoryUserRepository.class)
public interface UserRepository {

    User getUser(String id);

    void addUser(User user);

    void deleteUser(String id);

}
