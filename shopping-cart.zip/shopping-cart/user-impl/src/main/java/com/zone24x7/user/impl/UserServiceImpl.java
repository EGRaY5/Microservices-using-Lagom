/*
 * Copyright (C) 2016-2017 Lightbend Inc. <https://www.lightbend.com>
 */
package com.zone24x7.user.impl;

import akka.Done;
import akka.NotUsed;
import com.lightbend.lagom.javadsl.api.ServiceCall;

import javax.inject.Inject;

import com.zone24x7.user.api.User;
import com.zone24x7.user.api.UserService;

import java.util.concurrent.CompletableFuture;

/**
 * Implementation of the UserService.
 */
public class UserServiceImpl implements UserService {


  private UserRepository userRepository;

  @Inject
  public UserServiceImpl(UserRepository userRepository) {
    this.userRepository= userRepository;
  }

  @Override
  public ServiceCall<NotUsed, User> getUser(String id) {
    return request -> {
      User user = userRepository.getUser(id);
      return CompletableFuture.completedFuture(user);
    };
  }

  @Override
  public ServiceCall<User, Done> addUser() {

    return request -> {

      //add the user to the db
      userRepository.addUser(request);

      return CompletableFuture.completedFuture(Done.getInstance());
    };
  }

}
